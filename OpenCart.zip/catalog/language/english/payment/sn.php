<?php
// Text
$_['text_title']	= 'Online Payment Gateway';