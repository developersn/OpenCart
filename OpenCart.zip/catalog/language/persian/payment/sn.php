<?php
// Text
$_['text_title']	= 'درگاه پرداخت آنلاين';