<?php
// Text
$_['text_title']	= 'SN';