<?php
class ControllerPaymentSn extends Controller {
	public function index() {
		$this->language->load('payment/sn');

		$data['button_confirm'] = $this->language->get('button_confirm');

		$this->load->model('checkout/order');

		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

		if ($order_info) {
			$total = $this->currency->format($order_info['total'], $order_info['currency_code'], false, false);
			//$total = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
			//if($this->currency->getCode() != 'RLS') $total *= 10;
			//$order_info['currency_code']
			try
			{
// Security
@session_start();
$sec = uniqid();
$md = md5($sec.'vm');
// Security
				
$data_string = json_encode(array(
'pin'=> $this->config->get('sn_jpin'),
'price'=> $total,
'callback'=> $this->url->link('payment/sn/callback', '', 'SSL') ,
'order_id'=> $this->session->data['order_id'],
'ip'=> $_SERVER['REMOTE_ADDR'],
'callback_type'=>2
));

$ch = curl_init('https://developerapi.net/api/v1/request');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);


$json = json_decode($result,true);				
				
				if(!empty($json['result']) AND $json['result']==1)
				{
// Set Session
$_SESSION['sec']=$sec;
$_SESSION[$sec] = [
	'price'=>$total ,
	'order_id'=>$this->session->data['order_id'] ,
	'au'=>$json['au'] ,
];
					
					
					return '<div style="display:none">'.$json['form'].'</div>Please wait ... <script language="javascript">document.payment.submit(); </script>';
				}
				else
				{
					return $json['msg'];
				}
			}
			catch (SoapFault $ex)
			{
				die('Error2: error in get data from bank');
			}
		}
	}

	public function callback() {
// Security
$sec=$_SESSION['sec'];
// Security
	$transData = $_SESSION[$sec];
		if (isset($transData['order_id'])) {
			$order_id = $transData['order_id'];
		} else {
			$order_id = 0;
		}
		if (isset($transData['au'])) {
			$au = $transData['au'];
		} else {
			$au = 0;
		}
		$this->session->data['jau'] = NULL;

		$this->load->model('checkout/order');

		$order_info = $this->model_checkout_order->getOrder($order_id);
		if ($order_info) {
			$ok = false;
			$order_status_id = $this->config->get('config_order_status_id');
			$total = $this->currency->format($order_info['total'], $order_info['currency_code'], false, false);
			if ($this->config->get('sn_debug'))
			{
				$this->log->write('sn :: OrderID='.$order_id.' ::  au='.$au.' :: POST=' . implode($this->request->post).' :: GET=' . implode($this->request->get));
			}
			try
			{
				
$bank_return = $_POST + $_GET ;
$data_string = json_encode(array (
'pin' => $this->config->get('sn_jpin'),
'price' => $total,
'order_id' => $order_id,
'au' => $au,
'bank_return' =>$bank_return,
));

$ch = curl_init('https://developerapi.net/api/v1/verify');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);
$json = json_decode($result,true);				
				
				
				
				if($json['result']==1)
				{
					$ok = true;
					$order_status_id = $this->config->get('sn_completed_status_id');
				}
				else
				{
					$order_status_id = $this->config->get('sn_failed_status_id');
					if ($this->config->get('sn_debug'))
					{
						$this->log->write('sn :: OrderID='.$order_id.' :: error in verify ' . $res['result'] );
					}
				}
			}
			catch (SoapFault $ex)
			{
				die ('Error2: error in get data from bank.');
			}
			if (!$order_info['order_status_id']) {
				$this->model_checkout_order->addOrderHistory($order_id, $order_status_id);
			} else {
				$this->model_checkout_order->addOrderHistory($order_id, $order_status_id);
			}
			if ($ok == true)
			{
				header('location: '.$this->url->link('checkout/success'));
			}
			else
			{
				header('location: '.$this->url->link('checkout/checkout', '', 'SSL'));
			}
		}
	}
}